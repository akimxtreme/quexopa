$(function() {
if (window.PIE) {
$(function() {
$('div.home-concept div.process-image img').each(function() {
PIE.attach(this);
});
$('div.home-concept div.project-image img').each(function() {
PIE.attach(this);
});
}
});